package com.techwebsite.techWebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class TechWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechWebsiteApplication.class, args);
	}

}
