package com.techwebsite.techWebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
